# mcptool/__init__.py

def get_tool():
    from .app import MCPTool
    return MCPTool

__all__ = ['get_tool']
