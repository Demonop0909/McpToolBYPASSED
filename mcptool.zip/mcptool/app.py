import subprocess
import threading
import time
import sys
import os
from typing import Union
from loguru import logger
from rich.console import Console
from ezjsonpy import load_language, load_configuration, get_config_value, set_language
from .api.settings import APISettings
from .files import LocalFilesChecker, MCPToolPath
from .gui import MCPToolGUI
from .auth import Authentication
from .constants import MCPToolConstants
from .gui.banners import MCPToolBanner
from .files import WindowsInstaller
from .utilities.input import Input
from .updater import UpdaterCheck
from .api.api import MCPToolInternalAPI
from .utilities.tcp import PortChecker

console: Console = Console()

logger.add(sys.stdout, colorize=True, format='<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>')
logger.remove()
logger.add(os.path.join(MCPToolPath.get_mcptool_data_path(), 'logs.log'), level='DEBUG', format='[{time} {level} - {file}, {line}] ⮞ <level>{message}</level>', rotation='30 MB')

APISettings()

class MCPTool:

    def __init__(self) -> None:
        args = sys.argv[1:]
        self.skip_nodejs = '--skip-nodejs' in args
        self.skip_installer = '--skip-installer' in args
        self.auth = Authentication()

        try:
            if '--update' in args:
                WindowsInstaller().update()
                sys.exit(0)

            check_result = self._files_check()
            if not check_result:
               logger.error('Local files not found after restore')

            self._load()  # ✅ THIS MUST BE CALLED

        except KeyboardInterrupt:
           console.print('\n\n[red1]Exiting MCPTool...')
           time.sleep(2)
           sys.exit(0)


    def _files_check(self) -> bool:
        files_check_result = LocalFilesChecker().check(skip_nodejs=self.skip_nodejs)
        if not files_check_result:
            LocalFilesChecker().restore()
            return LocalFilesChecker().check(skip_nodejs=self.skip_nodejs)
        return True

    @staticmethod
    def _update_check() -> None:
        update_available = UpdaterCheck.update_available()
        if not update_available:
            pass
        return None

    def _load(self) -> None:
        try:
            load_configuration(config_name='default', config_path=os.path.join(MCPToolPath.get_mcptool_data_path(), 'settings.json'))

            for language in MCPToolConstants.LANGUAGES:
                lang_path = os.path.join(MCPToolPath.get_mcptool_data_path(), 'languages', f'{language}.json')
                if not os.path.exists(lang_path):
                    logger.warning(f'{language}.json not found')
                    sys.exit(1)
                load_language(language, lang_path)

            # Set language for sure
            lang = get_config_value('language')
            if not lang or lang == 'language':
                set_language('en')
            else:
                set_language(lang)

        except ValueError:
            logger.error('Error loading the settings file. (Invalid JSON format)')
            logger.info('Creating a new settings file')
            LocalFilesChecker().create_settings_file()
            self._load()


    def run(self) -> None:
        try:
            if os.name == 'nt':
                subprocess.run(f'title MCPTool v{MCPToolConstants.VERSION} - By @wrrulos', shell=True)

            port = int(get_config_value('api.port'))
            if PortChecker.check(port):
                logger.info('The mcptool API port is already in use!')

            elif get_config_value('api.enabled') and self.auth.plan != 'basic':
                api = MCPToolInternalAPI(authentication=self.auth, port=port)
                threading.Thread(target=api.run, daemon=True).start()

            MCPToolGUI(authentication=self.auth).menu()

        except KeyboardInterrupt:
            sys.exit(0)

if __name__ == "__main__":
    tool = MCPTool()
    tool.run()
