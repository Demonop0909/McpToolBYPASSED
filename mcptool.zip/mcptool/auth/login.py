import subprocess
import os
from rich.console import Console
from loguru import logger

console: Console = Console()

class Authentication:
    def __init__(self) -> None:
        """
Bypassed Authentication class.
Always returns successful login, no remote checks or cert validation.
"""
        self.username = "Unknown_Bypass"
        self.password = "bypassed_pass"
        self.system_code = "FAKE_SYSTEM_CODE"
        self.two_factor_code = None
        self.plan = "ultimate"
        self.logged_in = True  # Always set to True

    def _verify_cert_fingerprint(self, conn) -> bool:
        return True  # Bypass cert check

    def _https_get(self, url: str, params: dict) -> dict:
        logger.debug(f"[FAKE API CALL] GET {url} with {params}")
        return {"status": "success"}  # Simulated API response

    def login(self) -> bool:
        subprocess.run('cls' if os.name == 'nt' else 'clear', shell=True)
        self._set_window_title()
        logger.success("[AUTH BYPASS] Logged in without checking credentials.")
        return True

    def _set_window_title(self) -> None:
        if os.name == 'nt':
            subprocess.run('title Logged In - DeathenTool (Bypassed)', shell=True)

    def _load_account(self) -> bool:
        # Bypass loading real account
        self.username = "offline_user"
        self.password = "offline_pass"
        return True

    def _prompt_password(self, prompt_message: str) -> str:
        # Bypass password prompt
        return "bypassed_password"
