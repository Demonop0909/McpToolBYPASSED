from typing import Optional

class APISettings:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self) -> None:
        if self._initialized:
            return
        self._initialized = True
        self.bots_command: Optional[str] = None  # Proper default

    def set_bots_command(self, bots_command: str) -> None:
        self.bots_command = bots_command

    def get_bots_command(self) -> Optional[str]:
        return self.bots_command
